@echo off
cd /d "%~dp0"
start "" "%~dp0TrainSummer.exe" --rendering-method gl_compatibility
