Версия 0.8. Новая тройка: SummerBirch (лиственное дерево), SummerPine (хвойное дерево), OvergrownHouse (заросший дом с поврежденной крышей). Включены все предыдущие модели.

Каждая новая модель имеет три LOD. FBX содержит все LOD, маркеры осей и маски ветра в vertex color alpha. Генератор Unity-сцены полного пакета настраивает URP-материалы, LOD и GPU instancing. Шейдер ветра в UnityShaders предназначен для URP 14 Forward; не скомпилирован в Unity в среде создания.

Генераторам окружения нужны prop_pipeline.py и environment_pipeline.py рядом со скриптами. Blender/Source — исходники. Все изображения, включая SummerRouteEnvironment.png, получены в Blender; это не скриншоты Unity и не тест FPS. Материалы базовые без финальных фотореалистичных текстур.
